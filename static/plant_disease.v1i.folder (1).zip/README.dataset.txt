# plant_disease > 2025-10-30 12:58am
https://universe.roboflow.com/khushi-ico9e/plant_disease-dnruv

Provided by a Roboflow user
License: CC BY 4.0

